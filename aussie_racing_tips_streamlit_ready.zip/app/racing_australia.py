"""Free public-data importer for Racing Australia.

Racing Australia publishes public results/free-field pages. This module deliberately
uses only pages the user can access without credentials and stores the raw HTML for
troubleshooting. Page layouts can change, so parsing is defensive rather than tied
to one CSS selector.
"""
from __future__ import annotations

import re
from io import StringIO
from pathlib import Path
from datetime import date, timedelta
import pandas as pd
import requests

BASE = "https://www.racingaustralia.horse"
RESULTS_URL = BASE + "/FreeFields/Results.aspx?State={state}&Date={date}"
FORM_URL = BASE + "/FreeFields/Form.aspx?Key={key}"

HEADERS = {
    "User-Agent": "Mozilla/5.0 (compatible; HorseRacingTippingModel/1.0; +local-use)"
}


def fetch(url: str, timeout: int = 20) -> str:
    r = requests.get(url, headers=HEADERS, timeout=timeout)
    r.raise_for_status()
    return r.text


def _clean(v):
    if pd.isna(v):
        return None
    return re.sub(r"\s+", " ", str(v)).strip()


def _num(v):
    s = _clean(v)
    if not s:
        return None
    s = s.replace(",", "")
    m = re.search(r"-?\d+(?:\.\d+)?", s)
    return float(m.group()) if m else None


def _int(v):
    n = _num(v)
    return int(n) if n is not None else None


def _pick_col(df, patterns):
    for col in df.columns:
        c = str(col).lower().strip()
        if any(re.search(p, c) for p in patterns):
            return col
    return None


def parse_tables(html: str, race_date: str, state: str):
    """Best-effort parser for Racing Australia's public result tables.

    Returns normalized race and runner DataFrames. If the site changes layout,
    the raw response remains available to the caller for diagnostics.
    """
    tables = pd.read_html(StringIO(html))
    races, runners = [], []
    current_race = None
    race_no = 0

    for raw in tables:
        df = raw.copy()
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [" ".join(map(str, c)).strip() for c in df.columns]
        df.columns = [re.sub(r"\s+", " ", str(c)).strip() for c in df.columns]
        cols = [str(c).lower() for c in df.columns]
        horse_col = _pick_col(df, [r"horse", r"runner"])
        if not horse_col:
            continue
        # Result tables generally have a finishing position and/or barrier.
        pos_col = _pick_col(df, [r"^pos", r"finish", r"placing", r"place"])
        if not pos_col:
            continue

        track = None
        for text in df.astype(str).fillna("").head(5).to_numpy().flatten():
            if "race " in text.lower():
                current_race = text
                break

        race_no += 1
        rn = race_no
        m = re.search(r"race\s*(\d+)", str(current_race or ""), re.I)
        if m:
            rn = int(m.group(1))
        distance_col = _pick_col(df, [r"distance", r"metres", r"meters"])
        condition_col = _pick_col(df, [r"track", r"condition", r"going"])
        class_col = _pick_col(df, [r"class", r"grade"])
        barrier_col = _pick_col(df, [r"barrier", r"draw"])
        weight_col = _pick_col(df, [r"weight", r"kg"])
        jockey_col = _pick_col(df, [r"jockey", r"rider"])
        trainer_col = _pick_col(df, [r"trainer"])
        margin_col = _pick_col(df, [r"margin"])
        track_text = _clean(df.iloc[0][condition_col]) if condition_col else None
        distance = _int(df.iloc[0][distance_col]) if distance_col else None

        race_id = f"RA-{pd.Timestamp(race_date):%Y%m%d}-{state.upper()}-{rn}"
        races.append({
            "race_id": race_id, "date": str(pd.Timestamp(race_date).date()),
            "track": track or state.upper(), "race_number": rn,
            "distance": distance, "condition": track_text,
            "class_name": _clean(df.iloc[0][class_col]) if class_col else None,
            "prize_money": None,
        })
        for _, row in df.iterrows():
            horse = _clean(row[horse_col])
            if not horse or horse.lower() in {"nan", "horse", "runner"}:
                continue
            pos = _int(row[pos_col])
            runner_id = f"{race_id}-{re.sub(r'[^A-Za-z0-9]+','-',horse).strip('-').lower()}"
            runners.append({
                "runner_id": runner_id, "race_id": race_id, "horse": horse,
                "barrier": _int(row[barrier_col]) if barrier_col else None,
                "weight": _num(row[weight_col]) if weight_col else None,
                "jockey": _clean(row[jockey_col]) if jockey_col else None,
                "trainer": _clean(row[trainer_col]) if trainer_col else None,
                "age": None, "sex": None, "finish_position": pos,
                "margin_lengths": _num(row[margin_col]) if margin_col else None,
            })
    return pd.DataFrame(races).drop_duplicates("race_id"), pd.DataFrame(runners).drop_duplicates("runner_id")


def import_date(state: str, race_date: str, raw_dir: str = "data/raw"):
    Path(raw_dir).mkdir(parents=True, exist_ok=True)
    url = RESULTS_URL.format(state=state.upper(), date=pd.Timestamp(race_date).strftime("%d/%m/%Y"))
    html = fetch(url)
    raw_path = Path(raw_dir) / f"results_{state.lower()}_{pd.Timestamp(race_date):%Y%m%d}.html"
    raw_path.write_text(html, encoding="utf-8")
    return parse_tables(html, race_date, state), url, raw_path


def import_range(state: str, start: str, end: str, raw_dir: str = "data/raw"):
    out_r, out_p = [], []
    d, e = pd.Timestamp(start).date(), pd.Timestamp(end).date()
    while d <= e:
        try:
            (r, p), url, raw = import_date(state, str(d), raw_dir)
            if not r.empty: out_r.append(r)
            if not p.empty: out_p.append(p)
        except Exception as exc:
            print(f"{d}: {exc}")
        d += timedelta(days=1)
    races = pd.concat(out_r, ignore_index=True).drop_duplicates("race_id") if out_r else pd.DataFrame()
    runners = pd.concat(out_p, ignore_index=True).drop_duplicates("runner_id") if out_p else pd.DataFrame()
    return races, runners
