import argparse
from pathlib import Path
import pandas as pd
from app.db import connect, init_db
from app.racing_australia import import_range


def upsert(races, runners):
    init_db()
    with connect() as con:
        if not races.empty:
            races.to_sql("races", con, if_exists="append", index=False)
        if not runners.empty:
            runners.to_sql("runners", con, if_exists="append", index=False)


def main():
    ap = argparse.ArgumentParser(description="Import free public Racing Australia results")
    ap.add_argument("--state", default="VIC", help="Australian state code, e.g. VIC/NSW/QLD")
    ap.add_argument("--start", required=True, help="YYYY-MM-DD")
    ap.add_argument("--end", default=None, help="YYYY-MM-DD; defaults to start date")
    args = ap.parse_args()
    end = args.end or args.start
    races, runners = import_range(args.state, args.start, end)
    if races.empty:
        raise SystemExit("No races parsed. Racing Australia may have changed its page layout; inspect data/raw/*.html")
    # Avoid duplicate primary keys on repeated imports.
    with connect() as con:
        for _, r in races.iterrows():
            con.execute("""INSERT OR REPLACE INTO races
                (race_id,date,track,race_number,distance,condition,class_name,prize_money)
                VALUES (?,?,?,?,?,?,?,?)""", tuple(r.get(c) for c in ["race_id","date","track","race_number","distance","condition","class_name","prize_money"]))
        for _, r in runners.iterrows():
            con.execute("""INSERT OR REPLACE INTO runners
                (runner_id,race_id,horse,barrier,weight,jockey,trainer,age,sex,finish_position,margin_lengths)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)""", tuple(r.get(c) for c in ["runner_id","race_id","horse","barrier","weight","jockey","trainer","age","sex","finish_position","margin_lengths"]))
    print(f"Imported {len(races)} races and {len(runners)} runners.")

if __name__ == "__main__":
    main()
