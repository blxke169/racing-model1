import random
import numpy as np
import pandas as pd
from .db import init_db, reset_db, connect

def seed():
    reset_db()
    random.seed(42); np.random.seed(42)
    tracks = ["Flemington","Caulfield","Randwick","Moonee Valley","Rosehill"]
    conditions = ["Good","Soft","Heavy"]
    horses = [f"Horse {i:02d}" for i in range(1,81)]
    races=[]; runners=[]; odds=[]
    rid=0; uid=0
    for day in pd.date_range("2024-01-01","2024-06-30",freq="7D"):
        for rn in range(1,7):
            rid += 1
            race_id=f"R{rid:04d}"
            track=random.choice(tracks); cond=random.choices(conditions,[.55,.30,.15])[0]
            distance=random.choice([1000,1200,1400,1600,2000])
            races.append([race_id,day.date().isoformat(),track,rn,distance,cond,
                          random.choice(["BM64","BM70","BM78","Maiden","Listed"]),random.choice([30000,50000,80000,120000])])
            chosen=random.sample(horses,random.randint(8,14))
            # Persistent horse ability makes the dataset learnable.
            ability={h: np.random.normal(0,1) for h in chosen}
            scores=[]
            for h in chosen:
                uid+=1; runner_id=f"U{uid:05d}"
                barrier=random.randint(1,14); weight=random.uniform(52,60)
                score=ability[h] + np.random.normal(0,.8) - .035*(weight-55) - .025*(barrier-1)
                scores.append((runner_id,h,score))
            order=sorted(scores,key=lambda x:x[2],reverse=True)
            for pos,(runner_id,h,score) in enumerate(order,1):
                runners.append([runner_id,race_id,h,random.randint(1,14),random.uniform(52,60),
                                 f"Jockey {random.randint(1,20)}",f"Trainer {random.randint(1,30)}",
                                 random.randint(3,8),random.choice(["G","M","F"]),pos,round(max(0, np.random.normal(1.5,.7)),2)])
                # Market is noisy but somewhat informed.
                true_p=np.exp(score)/(sum(np.exp(s) for _,_,s in scores))
                market=max(.025,min(.6,true_p*np.exp(np.random.normal(0,.35))))
                price=max(1.5,round(1/market,2))
                odds.append([race_id,runner_id,"DemoBook",f"{day.date()}T09:00:00",price])
    with connect() as con:
        con.executemany("INSERT INTO races VALUES (?,?,?,?,?,?,?,?)", races)
        con.executemany("INSERT INTO runners VALUES (?,?,?,?,?,?,?,?,?,?,?)", runners)
        con.executemany("INSERT INTO odds(race_id,runner_id,bookmaker,timestamp,win_odds) VALUES (?,?,?,?,?)", odds)
    print(f"Seeded {len(races)} races and {len(runners)} runners.")
if __name__=="__main__": seed()
