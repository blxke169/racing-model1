import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parents[1] / "data" / "racing.db"

SCHEMA = '''
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS races (
 race_id TEXT PRIMARY KEY, date TEXT NOT NULL, track TEXT NOT NULL,
 race_number INTEGER, distance INTEGER, condition TEXT, class_name TEXT,
 prize_money REAL
);
CREATE TABLE IF NOT EXISTS runners (
 runner_id TEXT PRIMARY KEY, race_id TEXT NOT NULL REFERENCES races(race_id),
 horse TEXT NOT NULL, barrier INTEGER, weight REAL, jockey TEXT, trainer TEXT,
 age INTEGER, sex TEXT, finish_position INTEGER, margin_lengths REAL
);
CREATE TABLE IF NOT EXISTS odds (
 id INTEGER PRIMARY KEY AUTOINCREMENT, race_id TEXT NOT NULL,
 runner_id TEXT NOT NULL, bookmaker TEXT, timestamp TEXT, win_odds REAL
);
CREATE INDEX IF NOT EXISTS idx_runners_race ON runners(race_id);
CREATE INDEX IF NOT EXISTS idx_odds_runner ON odds(runner_id);
CREATE INDEX IF NOT EXISTS idx_races_date ON races(date);
'''

def connect():
    DB_PATH.parent.mkdir(exist_ok=True)
    con = sqlite3.connect(DB_PATH)
    con.execute("PRAGMA foreign_keys=ON")
    return con

def init_db():
    with connect() as con:
        con.executescript(SCHEMA)

def reset_db():
    with connect() as con:
        con.executescript("DROP TABLE IF EXISTS odds; DROP TABLE IF EXISTS runners; DROP TABLE IF EXISTS races;")
    init_db()
