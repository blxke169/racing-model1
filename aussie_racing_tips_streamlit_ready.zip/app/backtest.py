import numpy as np
import pandas as pd
from .model import make_features, train, predict, recommend

def walk_forward_backtest(races, runners, odds, min_edge=0.04, min_odds=2.5, max_odds=15):
    races = races.copy()
    races["date"] = pd.to_datetime(races["date"])
    dates = sorted(races["date"].dropna().unique())
    all_rows = []
    for d in dates:
        train_races = races[races["date"] < d]
        test_races = races[races["date"] == d]
        if len(train_races) < 10:
            continue
        train_ids = set(train_races.race_id)
        test_ids = set(test_races.race_id)
        tr = runners[runners.race_id.isin(train_ids)]
        te = runners[runners.race_id.isin(test_ids)]
        if tr.empty or te.empty:
            continue
        # Features are calculated from the full chronological history, but each
        # target row only contains prior completed runs.
        train_df = make_features(train_races, tr, odds)
        test_df = make_features(races[races.date <= d], te, odds)
        model = train(train_df.dropna(subset=["finish_position"]))
        pred = recommend(predict(model, test_df), min_edge, min_odds, max_odds)
        merged = pred.merge(te[["runner_id","finish_position"]], on="runner_id", how="left")
        merged["date"] = d
        merged["stake"] = np.where(merged["tip"]=="VALUE WIN", 1.0, 0.0)
        merged["profit"] = np.where(
            merged["tip"]=="VALUE WIN",
            np.where(merged["finish_position"]==1, merged["win_odds"]-1, -1),
            0.0
        )
        all_rows.append(merged)
    if not all_rows:
        return pd.DataFrame()
    return pd.concat(all_rows, ignore_index=True)

def metrics(results):
    if results.empty:
        return {"bets":0,"strike_rate":0,"profit":0,"roi":0,"max_drawdown":0}
    bets = results[results.tip=="VALUE WIN"].copy()
    if bets.empty:
        return {"bets":0,"strike_rate":0,"profit":0,"roi":0,"max_drawdown":0}
    equity = bets.profit.cumsum()
    peak = equity.cummax()
    dd = equity - peak
    return {
        "bets": len(bets),
        "strike_rate": float((bets.finish_position==1).mean()),
        "profit": float(bets.profit.sum()),
        "roi": float(bets.profit.sum()/len(bets)),
        "max_drawdown": float(dd.min())
    }
