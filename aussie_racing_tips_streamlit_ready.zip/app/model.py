from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import HistGradientBoostingClassifier, RandomForestClassifier
from sklearn.linear_model import LogisticRegression

NUMERIC = [
    "barrier","weight","age","distance","prize_money",
    "prior_runs","prior_wins","prior_places","win_rate","place_rate",
    "avg_finish","avg_margin","days_since_run","track_runs","track_wins",
    "distance_runs","distance_wins","condition_runs","condition_wins",
    "jockey_win_rate","trainer_win_rate","market_prob"
]
CATEGORICAL = ["track","condition","class_name","sex"]

def _history_features(races, runners):
    races = races.copy()
    runners = runners.copy()
    races["date"] = pd.to_datetime(races["date"])
    df = runners.merge(races, on="race_id", how="left")
    df = df.sort_values(["horse","date"]).reset_index(drop=True)
    rows = []
    history = {}
    for _, r in df.iterrows():
        key = r["horse"]
        h = history.get(key, [])
        prev = pd.DataFrame(h)
        f = {
            "prior_runs": len(h),
            "prior_wins": int(sum(x["win"] for x in h)),
            "prior_places": int(sum(x["place"] for x in h)),
            "win_rate": np.mean([x["win"] for x in h]) if h else 0.0,
            "place_rate": np.mean([x["place"] for x in h]) if h else 0.0,
            "avg_finish": np.mean([x["finish"] for x in h]) if h else np.nan,
            "avg_margin": np.mean([x["margin"] for x in h]) if h else np.nan,
            "days_since_run": (r["date"] - h[-1]["date"]).days if h else np.nan,
            "track_runs": sum(x["track"] == r["track"] for x in h),
            "track_wins": sum(x["track"] == r["track"] and x["win"] for x in h),
            "distance_runs": sum(x["distance"] == r["distance"] for x in h),
            "distance_wins": sum(x["distance"] == r["distance"] and x["win"] for x in h),
            "condition_runs": sum(x["condition"] == r["condition"] for x in h),
            "condition_wins": sum(x["condition"] == r["condition"] and x["win"] for x in h),
        }
        rows.append(f)
        if pd.notna(r["finish_position"]):
            h.append({
                "date": r["date"], "finish": float(r["finish_position"]),
                "margin": float(r["margin_lengths"]) if pd.notna(r["margin_lengths"]) else np.nan,
                "win": int(r["finish_position"] == 1),
                "place": int(r["finish_position"] <= 3),
                "track": r["track"], "distance": r["distance"], "condition": r["condition"]
            })
        history[key] = h
    feats = pd.DataFrame(rows, index=df.index)
    df = pd.concat([df, feats], axis=1)
    return df

def make_features(races, runners, odds=None):
    df = _history_features(races, runners)
    if odds is not None and not odds.empty:
        o = odds.copy()
        o["timestamp"] = pd.to_datetime(o["timestamp"])
        # Use the latest quoted price associated with each runner/race.
        o = o.sort_values("timestamp").groupby(["race_id","runner_id"], as_index=False).last()
        df = df.merge(o[["race_id","runner_id","win_odds"]], on=["race_id","runner_id"], how="left")
    else:
        df["win_odds"] = np.nan
    df["market_prob"] = np.where(df["win_odds"] > 1, 1/df["win_odds"], np.nan)
    df["jockey_win_rate"] = 0.10
    df["trainer_win_rate"] = 0.10
    return df

def build_pipeline():
    pre = ColumnTransformer([
        ("num", Pipeline([("impute", SimpleImputer(strategy="median")),
                          ("scale", StandardScaler())]), NUMERIC),
        ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                          ("onehot", OneHotEncoder(handle_unknown="ignore"))]), CATEGORICAL),
    ])
    return Pipeline([
        ("pre", pre),
        ("model", LogisticRegression(max_iter=2000, C=0.5, class_weight="balanced"))
    ])

def train(df):
    x = df[NUMERIC + CATEGORICAL]
    y = (df["finish_position"] == 1).astype(int)
    pipe = build_pipeline()
    pipe.fit(x, y)
    return pipe

def predict(pipe, df):
    p = pipe.predict_proba(df[NUMERIC + CATEGORICAL])[:,1]
    # Normalize within each race so probabilities form a coherent race book.
    out = df[["race_id","runner_id","horse","win_odds"]].copy()
    out["raw_probability"] = p
    out["model_probability"] = out.groupby("race_id")["raw_probability"].transform(lambda s: s / s.sum())
    out["fair_odds"] = 1 / out["model_probability"].clip(lower=0.001)
    out["market_probability"] = np.where(out["win_odds"] > 1, 1/out["win_odds"], np.nan)
    out["edge"] = out["model_probability"] - out["market_probability"]
    out["ev_per_dollar"] = np.where(out["win_odds"] > 1,
                                    out["model_probability"]*out["win_odds"] - 1, np.nan)
    return out.sort_values(["race_id","model_probability"], ascending=[True,False])

def recommend(pred, min_edge=0.04, min_odds=2.5, max_odds=15):
    p = pred.copy()
    p["tip"] = np.where(
        (p["edge"] >= min_edge) & (p["win_odds"] >= min_odds) & (p["win_odds"] <= max_odds),
        "VALUE WIN", "PASS"
    )
    return p
