import sys
from pathlib import Path
sys.path.append(str(Path(__file__).resolve().parents[1]))
import streamlit as st
import pandas as pd
from app.db import connect, init_db
from app.model import make_features, train, predict, recommend
from app.backtest import walk_forward_backtest, metrics

st.set_page_config(page_title="Australian Horse Racing Tipping Model", layout="wide")
init_db()

@st.cache_data
def load():
    with connect() as con:
        races=pd.read_sql_query("SELECT * FROM races ORDER BY date,race_number",con)
        runners=pd.read_sql_query("SELECT * FROM runners",con)
        odds=pd.read_sql_query("SELECT * FROM odds",con)
    races["date"] = pd.to_datetime(races["date"], errors="coerce")
    return races,runners,odds

races,runners,odds=load()
st.title("🏇 Australian Horse Racing Tipping Model")
st.caption("Public Racing Australia results/form → historical features → win model → race rankings → optional market value")

if races.empty:
    st.warning("No races in the database. Import public data with: python -m app.import_data --state VIC --start YYYY-MM-DD --end YYYY-MM-DD")
    st.stop()

with st.sidebar:
    st.subheader("Data source")
    st.write("Free source: Racing Australia public results/free-field pages")
    st.write("Odds: optional. Add bookmaker/exchange odds to `odds` for value betting.")

tab1,tab2,tab3=st.tabs(["Race Tips","Backtest","Database"])

with tab1:
    races["label"]=races.date.dt.strftime("%Y-%m-%d")+" • "+races.track.astype(str)+" • R"+races.race_number.astype(str)
    choice=st.selectbox("Select race",races.label.tolist()[::-1])
    race=races[races.label==choice].iloc[0]
    st.subheader(f"{race.track} — Race {race.race_number}")
    st.write(f"{race.date.date()} | {race.distance or '—'}m | {race.condition or '—'} | {race.class_name or '—'}")
    train_r=races[races.date < race.date]
    test_r=races[races.race_id==race.race_id]
    if len(train_r)<10:
        st.info("Not enough historical races to train the model yet. Import more history first.")
    else:
        tr=runners[runners.race_id.isin(train_r.race_id)]
        te=runners[runners.race_id.isin(test_r.race_id)]
        trf=make_features(train_r,tr,odds)
        tef=make_features(races[races.date<=race.date],te,odds)
        model=train(trf.dropna(subset=["finish_position"]))
        pred=recommend(predict(model,tef))
        pred=pred.merge(te[["runner_id","barrier","weight","jockey","trainer","finish_position"]],on="runner_id")
        pred["Model %"]=(pred.model_probability*100).round(1)
        pred["Edge %"]=(pred.edge*100).round(1)
        pred["Fair Odds"]=pred.fair_odds.round(2)
        pred["Market Odds"]=pred.win_odds.round(2)
        pred["Rank"] = range(1, len(pred)+1)
        cols=["Rank","horse","barrier","weight","jockey","Model %","Market Odds","Fair Odds","Edge %","tip"]
        st.dataframe(pred[cols],hide_index=True,use_container_width=True)
        if pred.win_odds.notna().any():
            tips=pred[pred.tip=="VALUE WIN"]
            st.success("Top value bets: "+", ".join(tips.head(3).horse)) if not tips.empty else st.info("No qualifying value bets. PASS.")
        else:
            st.info("No odds are loaded, so these are model rankings only — not value bets. Add pre-race odds to enable the value filter.")

with tab2:
    st.subheader("Walk-forward backtest")
    c1,c2,c3=st.columns(3)
    min_edge=c1.slider("Minimum edge",0.00,0.15,0.04,0.01)
    min_odds=c2.number_input("Minimum odds",1.01,20.0,2.5,0.25)
    max_odds=c3.number_input("Maximum odds",2.0,100.0,15.0,0.5)
    if st.button("Run backtest"):
        if odds.empty:
            st.warning("No odds table data is loaded. The model can be backtested for rankings, but not a realistic betting P/L until pre-race odds are imported.")
        with st.spinner("Running chronological backtest..."):
            res=walk_forward_backtest(races,runners,odds,min_edge,min_odds,max_odds)
        m=metrics(res)
        a,b,c,d=st.columns(4)
        a.metric("Bets",m["bets"]); b.metric("Strike rate",f"{m['strike_rate']*100:.1f}%")
        c.metric("Profit / 1u",f"{m['profit']:.2f}u"); d.metric("ROI",f"{m['roi']*100:.1f}%")
        st.metric("Max drawdown",f"{m['max_drawdown']:.2f}u")
        if not res.empty and (res.tip=="VALUE WIN").any():
            st.line_chart(res[res.tip=="VALUE WIN"].set_index("date")["profit"].cumsum())
            st.dataframe(res[res.tip=="VALUE WIN"][["date","horse","win_odds","model_probability","edge","finish_position","profit"]],hide_index=True,use_container_width=True)

with tab3:
    st.subheader("Database")
    a,b,c=st.columns(3)
    a.metric("Races",len(races)); b.metric("Runners",len(runners)); c.metric("Odds",len(odds))
    st.write("Tables: `races`, `runners`, `odds`. Public source: Racing Australia.")
