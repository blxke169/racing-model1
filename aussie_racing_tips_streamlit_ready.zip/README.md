# Aussie Racing Tips — Streamlit deployment

This repository is ready to deploy on Streamlit Community Cloud.

## Streamlit Cloud

1. Put the contents of this folder into a **public GitHub repository**.
2. Open https://share.streamlit.io/ and sign in with GitHub.
3. Choose the repository and select `streamlit_app.py` as the main file.
4. Click **Deploy**.

The app includes a bundled SQLite database with the current model/demo data so the site can open immediately after deployment.

## Important data note

The bundled database is historical starter data. The free Racing Australia importer uses public result pages and is best-effort; it is **not** a licensed live Australian racing or bookmaker-odds API. Public page layouts can change. Live pre-race odds are not included by default, so the app must not be treated as a live value-betting feed until genuine pre-race odds are supplied.

## Local run

```bash
pip install -r requirements.txt
streamlit run streamlit_app.py
```

## Project files

- `streamlit_app.py` — Streamlit entry point
- `requirements.txt` — Cloud dependencies
- `.streamlit/config.toml` — deployment settings
- `.python-version` — Python runtime hint
- `app/` — database, model, importer and backtesting code
- `data/racing.db` — bundled starter database
