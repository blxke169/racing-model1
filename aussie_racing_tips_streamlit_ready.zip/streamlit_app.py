import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

import streamlit as st
import pandas as pd

from app.db import connect, init_db
from app.model import make_features, train, predict, recommend

st.set_page_config(
    page_title="Aussie Racing Tips",
    page_icon="🏇",
    layout="centered",
    initial_sidebar_state="collapsed",
)

init_db()

st.markdown("""
<style>
.block-container {max-width: 760px; padding-top: 1.2rem; padding-bottom: 4rem;}
[data-testid="stMetricValue"] {font-size: 1.35rem;}
.tip-card {padding: 14px 16px; border: 1px solid rgba(128,128,128,.25); border-radius: 14px; margin: 8px 0;}
.small {opacity: .72; font-size: .88rem;}
</style>
""", unsafe_allow_html=True)

@st.cache_data(ttl=60)
def load_data():
    with connect() as con:
        races = pd.read_sql_query("SELECT * FROM races ORDER BY date, race_number", con)
        runners = pd.read_sql_query("SELECT * FROM runners", con)
        odds = pd.read_sql_query("SELECT * FROM odds", con)
    if not races.empty:
        races["date"] = pd.to_datetime(races["date"], errors="coerce")
    return races, runners, odds

races, runners, odds = load_data()

st.title("🏇 Aussie Racing Tips")
st.caption("Model rankings • fair odds • value detection")

if races.empty:
    st.warning("No racing data is loaded yet.")
    st.info("Add historical racing data to the database, then refresh this page.")
    st.stop()

# Latest race first
races = races.sort_values(["date", "race_number"], ascending=[False, False])
races["label"] = races.apply(
    lambda r: f"{r.date:%d %b %Y} • {r.track} • R{int(r.race_number)}", axis=1
)

choice = st.selectbox("Choose a race", races["label"].tolist())
race = races.loc[races["label"] == choice].iloc[0]

st.subheader(f"{race.track} — Race {int(race.race_number)}")
meta = []
if pd.notna(race.get("distance")): meta.append(f"{int(race.distance)}m")
if pd.notna(race.get("condition")): meta.append(str(race.condition))
if pd.notna(race.get("class_name")): meta.append(str(race.class_name))
st.caption(" • ".join(meta) if meta else f"{race.date:%A, %d %B %Y}")

train_r = races[races.date < race.date]
test_r = races[races.race_id == race.race_id]

if len(train_r) < 10:
    st.info("Not enough historical races to train the model yet. Import more history first.")
    st.stop()

tr = runners[runners.race_id.isin(train_r.race_id)]
te = runners[runners.race_id.isin(test_r.race_id)]

trf = make_features(train_r, tr, odds)
tef = make_features(races[races.date <= race.date], te, odds)
model = train(trf.dropna(subset=["finish_position"]))
pred = recommend(predict(model, tef))

pred = pred.merge(
    te[["runner_id", "barrier", "weight", "jockey", "trainer", "finish_position"]],
    on="runner_id", how="left"
)
pred = pred.sort_values("model_probability", ascending=False).reset_index(drop=True)
pred["Model %"] = (pred.model_probability * 100).round(1)
pred["Fair Odds"] = pred.fair_odds.round(2)
pred["Market Odds"] = pred.win_odds.round(2)
pred["Edge %"] = (pred.edge * 100).round(1)
pred["Rank"] = range(1, len(pred) + 1)

# Main pick
if not pred.empty:
    top = pred.iloc[0]
    st.markdown("### ⭐ Top model pick")
    st.markdown(f"<div class='tip-card'><b>#{int(top.Rank)} {top.horse}</b><br>Model win chance: <b>{top['Model %']:.1f}%</b> • Fair odds: <b>${top['Fair Odds']:.2f}</b><br><span class='small'>Barrier {top.barrier} • {top.jockey or 'Jockey unavailable'}</span></div>", unsafe_allow_html=True)

st.markdown("### 📊 Runner rankings")
cols = ["Rank", "horse", "Model %", "Fair Odds", "barrier", "weight"]
show = pred[cols].copy()
show.columns = ["#", "Horse", "Model %", "Fair Odds", "Barrier", "Weight"]
st.dataframe(show, hide_index=True, use_container_width=True)

if pred.win_odds.notna().any():
    st.markdown("### 💰 Value bets")
    tips = pred[pred.tip == "VALUE WIN"].head(3)
    if tips.empty:
        st.info("No runners currently meet the model's value filter.")
    else:
        for _, row in tips.iterrows():
            st.success(f"#{int(row.Rank)} {row.horse} — market ${row['Market Odds']:.2f} vs fair ${row['Fair Odds']:.2f} — edge {row['Edge %']:.1f}%")
else:
    st.info("💡 No bookmaker odds are loaded. The rankings are model selections, not value-bet recommendations.")

with st.expander("How this works"):
    st.write("The model trains only on races before the selected race, then produces race-normalised win probabilities and fair odds. Value bets require genuine pre-race market odds.")

with st.expander("Data status"):
    a, b, c = st.columns(3)
    a.metric("Races", len(races))
    b.metric("Runners", len(runners))
    c.metric("Odds", len(odds))
    st.caption("Free source: Racing Australia public pages. Public pages can change and are not a substitute for a licensed live data/odds feed.")
